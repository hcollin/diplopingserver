package com.frosttroll.diploping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiplomacyPingerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiplomacyPingerApplication.class, args);
	}
}
