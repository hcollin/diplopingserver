package fi.collin.diploping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiplopingApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiplopingApplication.class, args);
	}
}
